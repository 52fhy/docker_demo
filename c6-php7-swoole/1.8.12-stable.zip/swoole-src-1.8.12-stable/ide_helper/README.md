Swoole IDE helper
===
```shell
php dump.php
```
Add `swoole.php` to your ide include path.